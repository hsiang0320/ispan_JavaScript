document.write("EEIT61<br>JavaScript");
var a=10;
